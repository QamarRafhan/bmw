<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('get_sub_categories', function (Blueprint $table) {
            $table->integer('sub_category_id')->nullable();
            $table->string('sub_category_name', 150)->nullable();
            $table->string('sub_category_slug', 150)->nullable();
            $table->string('sub_category_image', 250)->nullable();
            $table->integer('selected_category_id')->nullable();
            $table->timestamp('created_at')->useCurrentOnUpdate()->useCurrent();
            $table->string('category_name', 150)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('get_sub_categories');
    }
};

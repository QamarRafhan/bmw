<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('get_vendor_data', function (Blueprint $table) {
            $table->unsignedBigInteger('id')->nullable();
            $table->string('photo', 250)->nullable();
            $table->string('name')->nullable();
            $table->string('email')->nullable();
            $table->string('username', 200)->nullable();
            $table->string('shop_name', 200)->nullable();
            $table->timestamp('created_at')->useCurrentOnUpdate()->useCurrent();
            $table->text('shop_description')->nullable();
            $table->string('phone_number', 20)->nullable();
            $table->string('address', 200)->nullable();
            $table->integer('vendor_id')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('get_vendor_data');
    }
};
